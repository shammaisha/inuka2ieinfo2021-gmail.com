     <---------------UNIVERSITE INUKA--------------->

     		NOM     :  Izidor
     		Prenom  :  Zadora Shamma
     		Niveau  :  2eme annee sciences informatiques
     		vacation:  Median A.